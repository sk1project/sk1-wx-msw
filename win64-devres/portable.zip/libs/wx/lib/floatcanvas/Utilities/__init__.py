"""
__init__ for the floatcanvas Utilities package

"""
pass


